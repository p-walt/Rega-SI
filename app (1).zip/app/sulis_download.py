from pathlib import Path
import os
import subprocess

directory = Path(f'{str(Path("/")).join(str(Path.cwd()).split(str(Path("/")))[:-1])}/app/Calculation_data')
print(Path.cwd)
print(directory)
dir_list = []
for fi in os.listdir(directory):
    d = os.path.join(directory, fi)
    if os.path.isdir(d):
        dir_list.append(d)
with open(str(Path(f'{directory}/remote_filelist1.txt')), 'r') as comp_calcs:
    clines1 = comp_calcs.readlines()
    cline2 = []
    print(f'CLINES {clines1}')
    for cline1 in clines1:

        ct = cline1.strip('\n')
        ct_split = ct.split('/')
        print(ct_split)
        cline2.append(ct_split)
        for dir in dir_list:
            di = dir.split(str(Path('/')))[-1]
            print(str(Path(f'{directory}/{di}/{ct_split[0]}/{ct_split[1]}/hfoutp.in')))
            if os.path.isfile(str(Path(f'{directory}/{di}/{ct_split[0]}/{ct_split[1]}/hfoutp.in'))):
                print('rsync', '-e', r'ssh -i C:\Users\pcypw1\.ssh\sulis_key', '-a', f'-v pcypw1@login.sulis.ac.uk:/home/p/pcypw1/11May0847/{ct_split[0]}/{ct_split[1]}/hfoutp.out .\\{str(Path(f"Calculation_data/{di}/{ct_split[0]}/{ct_split[1]}/hfoutp.out"))}')
                outp = subprocess.Popen(['rsync', '-e', r'ssh -i C:\Users\pcypw1\.ssh\sulis_key', '-a', '-v',
                                                      'pcypw1@login.sulis.ac.uk:' + '/home/p/pcypw1/11May0847' + '/' + ct_split[0] + '/' + ct_split[1] + '/' 'hfoutp.out', '.\\' + str(Path(f"Calculation_data/{di}/{ct_split[0]}/{ct_split[1]}/hfoutp.out"))],
                                                     stderr=subprocess.STDOUT, stdout=subprocess.PIPE).communicate()[0]
                status = outp.decode().split('\n')[-2]
                print(status)
                continue


        print('NEXT')
